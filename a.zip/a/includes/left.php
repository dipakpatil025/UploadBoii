<div class="left">
    <div class="title">UPLOADBOI</div>
    <div class="menu-container">
        <a class="menu-item" href="./"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a class="menu-item" href="./users"><i class="fas fa-users"></i> Users</a>
        <a class="menu-item" href="./files"><i class="fas fa-folder-open"></i> Files</a>
        <a class="menu-item" href="./messages"><i class="fas fa-envelope"></i> Messages</a>
        <a class="menu-item" href="./notifications"><i class="fas fa-envelope"></i>sent messages</a>
        <a class="menu-item" href="./settings"><i class="fas fa-cog"></i> Settings</a>
        <a class="menu-item" href="./logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>